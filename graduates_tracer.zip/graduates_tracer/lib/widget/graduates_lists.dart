import 'package:flutter/material.dart';
import 'graduates_lists_department.dart'; // Import for department tables

class GraduatesLists extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 100,
        title: Row(
          children: [
            Image.asset('assets/logo.png', height: 60), // University logo
            const SizedBox(width: 10),
            const Text(
              'CareerPathLink',
              style: TextStyle(
                color: Colors.black,
                fontSize: 24,
                fontWeight: FontWeight.bold,
                fontFamily: 'Montserrat',
              ),
            ),
          ],
        ),
        actions: [
          Row(
            children: [
              const Text(
                'College Deans',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                ),
              ),
              const SizedBox(width: 8),
              CircleAvatar(
                backgroundImage: AssetImage('assets/user.png'), // User photo
              ),
              const Icon(Icons.arrow_drop_down, color: Colors.black),
              const SizedBox(width: 16),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Separator bar
          Container(
            color: Colors.grey[300],
            padding: const EdgeInsets.all(16.0),
            child: const Center(
              child: Text(
                'Graduates Lists',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Montserrat',
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Department Grid
          Expanded(
            child: GridView.count(
              crossAxisCount: 4, // 4 containers per row
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              padding: const EdgeInsets.all(16.0),
              children: [
                departmentContainer(context, 'School of Social and Natural Sciences', 'assets/social_sciences_logo.png'),
                departmentContainer(context, 'College of Engineering and Architecture', 'assets/engineering_logo.png'),
                departmentContainer(context, 'School of Business and Accountancy', 'assets/business_logo.png'),
                departmentContainer(context, 'School of Computer and Information Sciences', 'assets/computer_logo.png'),
                departmentContainer(context, 'School of Law', 'assets/law_logo.png'),
                departmentContainer(context, 'School of Teachers Education', 'assets/education_logo.png'),
                departmentContainer(context, 'College of Criminal Justice Education', 'assets/criminal_justice_logo.png'),
                departmentContainer(context, 'School of Nursing and Allied Health Sciences', 'assets/nursing_logo.png'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget departmentContainer(BuildContext context, String name, String logoPath) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => GraduatesListsDepartment(departmentName: name),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              logoPath,
              height: 60,
              width: 60,
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Text(
                name,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Montserrat',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
