import 'package:flutter/material.dart';
import 'package:graduates_tracer/models/GraduatesLists.dart';
import 'package:graduates_tracer/services/graduates_lists_api_service.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class GraduatesListsDepartment extends StatefulWidget {
  final String departmentName;

  const GraduatesListsDepartment({super.key, required this.departmentName});

  @override
  _GraduatesListsDepartmentState createState() =>
      _GraduatesListsDepartmentState();
}

class _GraduatesListsDepartmentState extends State<GraduatesListsDepartment> {
  late Future<List<GraduatesList>> futureGraduatesLists;
  final GraduatesListApiService apiService = GraduatesListApiService();
  // List graduates = [];
  final controllers = <String, TextEditingController>{};

  @override
  void initState() {
    super.initState();
    futureGraduatesLists = apiService.fetchGraduatesList();
    // fetchGraduates();
  }

  // Future<void> fetchGraduates() async {
  //   try {
  //     final response = await http.get(Uri.parse('http://127.0.0.1/read.php'));
  //     if (response.statusCode == 200) {
  //       setState(() {
  //         graduates = json.decode(response.body);
  //       });
  //     } else {
  //       print('Failed to fetch graduates. Status code: ${response.statusCode}');
  //       print('Response body: ${response.body}');
  //     }
  //   } catch (e) {
  //     print('Error fetching graduates: $e');
  //   }
  // }


  Future<void> deleteGraduate(String studentNo) async {
    try {
      final response = await http
          .get(Uri.parse('http://localhost/delete.php?student_no=$studentNo'));
      if (response.statusCode == 200) {
        setState(() {
          // graduates.removeWhere((graduate) => graduate['student_no'] == studentNo);
        });
      } else {
        print('Failed to delete graduate. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error deleting graduate: $e');
    }
  }

  // Future<void> updateGraduate(String studentNo) async {
  //   try {
  //     final response = await http.post(
  //       Uri.parse('http://localhost/update.php'),
  //       headers: {'Content-Type': 'application/json'},
  //       body: json.encode({
  //         'student_no': controllers['student_no']!.text,
  //         'last_name': controllers['last_name']!.text,
  //         'first_name': controllers['first_name']!.text,
  //         'middle_name': controllers['middle_name']!.text,
  //         'birthdate': controllers['birthdate']!.text,
  //         'age': int.tryParse(controllers['age']!.text) ?? 0,
  //         'home_address': controllers['home_address']!.text,
  //         'unc_email': controllers['unc_email']!.text,
  //         'personal_email': controllers['personal_email']!.text,
  //         'facebook_name': controllers['facebook_name']!.text,
  //         'course': controllers['course']!.text,
  //         '1st_target_employer': controllers['1st_target_employer']!.text,
  //         '2nd_target_employer': controllers['2nd_target_employer']!.text,
  //         '3rd_target_employer': controllers['3rd_target_employer']!.text,
  //         'graduation_date': controllers['graduation_date']!.text,
  //       }),
  //     );
  //     if (response.statusCode == 200) {
  //       fetchGraduates();
  //     } else {
  //       print('Failed to update graduate. Status code: ${response.statusCode}');
  //     }
  //   } catch (e) {
  //     print('Error updating graduate: $e');
  //   }
  // }

  Future<void> createGraduate() async {
    try {
      final response = await http.post(
        Uri.parse('http://localhost/create.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'student_no': controllers['student_no']?.text,
          'last_name': controllers['last_name']?.text,
          'first_name': controllers['first_name']?.text,
          'middle_name': controllers['middle_name']?.text,
          'birthdate': controllers['birthdate']?.text,
          'age': int.tryParse(controllers['age']?.text ?? '0') ?? 0,
          'home_address': controllers['home_address']?.text,
          'unc_email': controllers['unc_email']?.text,
          'personal_email': controllers['personal_email']?.text,
          'facebook_name': controllers['facebook_name']?.text,
          'course': controllers['course']?.text,
          '1st_target_employer': controllers['1st_target_employer']?.text,
          '2nd_target_employer': controllers['2nd_target_employer']?.text,
          '3rd_target_employer': controllers['3rd_target_employer']?.text,
          'graduation_date': controllers['graduation_date']?.text,
        }),
      );
      if (response.statusCode == 200) {
        // fetchGraduates();
      } else {
        print('Failed to create graduate. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error creating graduate: $e');
    }
  }

  void showUpdateDialog(Map<String, dynamic> graduate) {
    controllers.clear();
    graduate.forEach((key, value) {
      controllers[key] = TextEditingController(text: value?.toString() ?? '');
    });

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Update Graduate'),
          content: SingleChildScrollView(
            child: Column(
              children: controllers.keys.map((key) {
                return TextField(
                  controller: controllers[key],
                  decoration: InputDecoration(
                      labelText: key.replaceAll('_', ' ').toUpperCase()),
                );
              }).toList(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                // updateGraduate(graduate['student_no']);
                Navigator.of(context).pop();
              },
              child: const Text('Update'),
            ),
          ],
        );
      },
    );
  }

  void showCreateDialog() {
    controllers.clear();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Create Graduate'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                for (String key in [
                  'student_no',
                  'last_name',
                  'first_name',
                  'middle_name',
                  'birthdate',
                  'age',
                  'home_address',
                  'unc_email',
                  'personal_email',
                  'facebook_name',
                  'course',
                  '1st_target_employer',
                  '2nd_target_employer',
                  '3rd_target_employer',
                  'graduation_date'
                ])
                  TextField(
                    controller: controllers[key] = TextEditingController(),
                    decoration: InputDecoration(
                        labelText: key.replaceAll('_', ' ').toUpperCase()),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                createGraduate();
                Navigator.of(context).pop();
              },
              child: const Text('Create'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.departmentName),
      ),
      body: FutureBuilder<List<GraduatesList>>(
        future: futureGraduatesLists,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No graduates found.'));
          }

          final graduates = snapshot.data!;
          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: const [
                DataColumn(label: Text('Student No')),
                DataColumn(label: Text('Name')),
                DataColumn(label: Text('Course')),
                DataColumn(label: Text('Graduation Date')),
                DataColumn(label: Text('Actions')),
              ],
              rows: graduates.map((graduate) {
                return DataRow(cells: [
                  DataCell(Text(graduate.studentNo.toString() ?? 'N/A')),
                  DataCell(Text('${graduate.firstName} ${graduate.lastName}')),
                  DataCell(Text(graduate.course ?? 'N/A')),
                  DataCell(Text(graduate.graduationDate.toString() ?? 'N/A')),
                  DataCell(Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () {
                          // Implement update logic here
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () {
                          // Implement delete logic here
                        },
                      ),
                    ],
                  )),
                ]);
              }).toList(),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: showCreateDialog,
        child: const Icon(Icons.add),
      ),
    );
  }
}
