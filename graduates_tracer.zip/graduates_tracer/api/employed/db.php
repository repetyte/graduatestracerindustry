<?php
$host = 'localhost';
$db_name = 'graduates_tracer_industry'; // Replace with your database name
$username = 'root'; // Replace with your database username
$password = ''; // Replace with your database password';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $exception) {
    die("Connection failed: " . $exception->getMessage());
}
?>
