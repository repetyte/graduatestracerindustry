package com.example.graduates_tracer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
